Original, unmodified input files belong here.
