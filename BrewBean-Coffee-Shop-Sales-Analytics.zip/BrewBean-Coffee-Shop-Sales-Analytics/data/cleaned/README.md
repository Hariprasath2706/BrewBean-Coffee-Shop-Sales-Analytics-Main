Validated and cleaned files used for analysis belong here.
